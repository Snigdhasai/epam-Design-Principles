package com.epam.calculator_Desgin_Principles;

public interface ExtraOperators {
	public Integer expo();
	public Integer modulus();
}
